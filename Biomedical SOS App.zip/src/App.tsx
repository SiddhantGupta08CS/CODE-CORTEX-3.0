import { RouterProvider, createBrowserRouter } from "react-router";
import RootLayout from "./layouts/RootLayout";
import Dashboard from "./pages/Dashboard";
import Records from "./pages/Records";
import Doctor from "./pages/Doctor";
import SOS from "./pages/SOS";

const router = createBrowserRouter([
  {
    path: "/",
    Component: RootLayout,
    children: [
      { index: true, Component: Dashboard },
      { path: "records", Component: Records },
      { path: "doctor", Component: Doctor },
    ],
  },
  {
    path: "/sos",
    Component: SOS, // Full screen mode, no layout
  }
]);

export default function App() {
  return <RouterProvider router={router} />;
}