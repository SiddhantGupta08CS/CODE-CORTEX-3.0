import { Outlet, NavLink, useNavigate } from "react-router";
import { Home, FileText, UserPlus, Mic } from "lucide-react";

export default function RootLayout() {
  const navigate = useNavigate();

  return (
    <div className="flex flex-col min-h-[100dvh] relative max-w-md mx-auto bg-background shadow-2xl overflow-hidden">
      
      {/* Main Content */}
      <main className="flex-1 overflow-y-auto pb-24">
        <Outlet />
      </main>

      {/* Persistent SOS Floating Action Button */}
      <div className="absolute bottom-24 right-6 z-50">
        <button 
          onClick={() => navigate("/sos")}
          className="bg-red-500 hover:bg-red-600 text-white p-4 rounded-full shadow-[0_8px_30px_rgb(239,68,68,0.3)] flex items-center justify-center transition-transform active:scale-95"
          aria-label="Trigger SOS"
        >
          <Mic className="w-6 h-6" />
        </button>
      </div>

      {/* Bottom Navigation */}
      <nav className="absolute bottom-0 w-full max-w-md bg-white/90 backdrop-blur-md border-t border-border flex justify-around items-center h-20 z-40 pb-safe">
        <NavLink 
          to="/" 
          end
          className={({isActive}) => `flex flex-col items-center justify-center w-full h-full space-y-1.5 transition-colors ${isActive ? 'text-blue-600' : 'text-gray-400 hover:text-gray-600'}`}
        >
          <Home className="w-6 h-6" />
          <span className="text-[11px] font-medium">Home</span>
        </NavLink>
        
        <NavLink 
          to="/records" 
          className={({isActive}) => `flex flex-col items-center justify-center w-full h-full space-y-1.5 transition-colors ${isActive ? 'text-blue-600' : 'text-gray-400 hover:text-gray-600'}`}
        >
          <FileText className="w-6 h-6" />
          <span className="text-[11px] font-medium">Records</span>
        </NavLink>

        <NavLink 
          to="/doctor" 
          className={({isActive}) => `flex flex-col items-center justify-center w-full h-full space-y-1.5 transition-colors ${isActive ? 'text-blue-600' : 'text-gray-400 hover:text-gray-600'}`}
        >
          <UserPlus className="w-6 h-6" />
          <span className="text-[11px] font-medium">Care Team</span>
        </NavLink>
      </nav>
    </div>
  );
}