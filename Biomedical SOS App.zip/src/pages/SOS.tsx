import { useEffect, useState } from "react";
import { AlertTriangle, Phone, Radio, ShieldAlert, HeartPulse, FileHeart, CheckCircle2, Siren } from "lucide-react";
import { useNavigate } from "react-router";

export default function SOS() {
  const navigate = useNavigate();
  const [stages, setStages] = useState({
    alarm: false,
    bypass: false,
    hospital: false,
    contacts: false,
    nearby: false
  });

  useEffect(() => {
    // Simulate the sequence of automated actions
    setTimeout(() => setStages(s => ({ ...s, alarm: true })), 500);
    setTimeout(() => setStages(s => ({ ...s, bypass: true })), 1500);
    setTimeout(() => setStages(s => ({ ...s, hospital: true })), 2500);
    setTimeout(() => setStages(s => ({ ...s, contacts: true })), 3500);
    setTimeout(() => setStages(s => ({ ...s, nearby: true })), 4500);
  }, []);

  return (
    <div className="min-h-[100dvh] bg-destructive text-destructive-foreground p-4 flex flex-col justify-between max-w-md mx-auto relative overflow-hidden">
      
      {/* Siren Animation Background */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-20">
        <div className="w-64 h-64 bg-white rounded-full animate-ping" style={{ animationDuration: '1.5s' }} />
        <div className="absolute w-96 h-96 bg-white rounded-full animate-ping" style={{ animationDuration: '2s' }} />
      </div>

      {/* Main Content */}
      <div className="relative z-10 flex-1 flex flex-col pt-8">
        <div className="flex justify-center mb-6">
          <div className="bg-white text-destructive p-4 rounded-full animate-pulse">
            <AlertTriangle className="w-12 h-12" />
          </div>
        </div>
        
        <h1 className="text-4xl font-black text-center mb-2 uppercase tracking-tight">Medical Emergency</h1>
        <p className="text-center text-xl font-bold mb-8 bg-white/20 p-3 rounded-lg backdrop-blur-sm">
          DO NOT MOVE THE PATIENT
        </p>

        {/* Vital Info for Bystanders */}
        <div className="bg-white text-foreground rounded-2xl p-5 mb-8 shadow-2xl">
          <h2 className="text-lg font-bold border-b pb-2 mb-3 text-destructive">Bystander Instructions</h2>
          <ul className="space-y-3 font-medium">
            <li className="flex items-start gap-3">
              <span className="bg-destructive text-white rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 mt-0.5">1</span>
              <p>Ambulance has been automatically called and is en route to this GPS location.</p>
            </li>
            <li className="flex items-start gap-3">
              <span className="bg-destructive text-white rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 mt-0.5">2</span>
              <p>Patient has a history of Cardiac Arrhythmia.</p>
            </li>
            <li className="flex items-start gap-3">
              <span className="bg-destructive text-white rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 mt-0.5">3</span>
              <p>Ensure airway is clear. Perform CPR only if breathing stops.</p>
            </li>
          </ul>
        </div>

        {/* Action Status Log */}
        <div className="space-y-3 text-sm font-medium bg-black/10 p-4 rounded-xl backdrop-blur-sm">
          <StatusRow active={stages.alarm} text="Sounding maximum volume siren" icon={Siren} />
          <StatusRow active={stages.bypass} text="Security bypassed for medics" icon={ShieldAlert} />
          <StatusRow active={stages.hospital} text="Nearest Hospital (St. Jude) Pre-admitted" icon={FileHeart} />
          <StatusRow active={stages.contacts} text="Emergency Contacts notified" icon={Phone} />
          <StatusRow active={stages.nearby} text="Alert broadcast to phones in 2m radius" icon={Radio} />
        </div>
      </div>

      {/* Cancel Button */}
      <div className="relative z-10 pt-8 pb-4">
        <p className="text-center text-xs opacity-70 mb-3">Press and hold to cancel if false alarm</p>
        <button 
          onClick={() => navigate('/')}
          className="w-full bg-white/10 hover:bg-white/20 border border-white/30 text-white font-bold py-4 rounded-xl transition-all"
        >
          CANCEL SOS
        </button>
      </div>
    </div>
  );
}

function StatusRow({ active, text, icon: Icon }: { active: boolean, text: string, icon: any }) {
  return (
    <div className={`flex items-center gap-3 transition-opacity duration-500 ${active ? 'opacity-100' : 'opacity-40'}`}>
      {active ? <CheckCircle2 className="w-5 h-5 text-green-300 shrink-0" /> : <Icon className="w-5 h-5 shrink-0" />}
      <span>{text}</span>
    </div>
  )
}