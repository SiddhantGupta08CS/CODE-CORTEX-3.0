import { Activity, AlertCircle, MapPin, Phone, HeartPulse, User, Camera } from "lucide-react";
import { useNavigate } from "react-router";

export default function Dashboard() {
  const navigate = useNavigate();

  return (
    <div className="p-6 space-y-10">
      {/* Header */}
      <header className="flex justify-between items-center pt-2">
        <div>
          <h1 className="text-3xl font-semibold tracking-tight">Hi, David</h1>
          <p className="text-muted-foreground text-sm mt-1">Monitoring active</p>
        </div>
        <div className="bg-green-50 text-green-600 p-3 rounded-full">
          <Activity className="w-5 h-5" />
        </div>
      </header>

      {/* SOS Voice Helper Banner */}
      <div 
        onClick={() => navigate('/sos')}
        className="bg-red-50/50 hover:bg-red-50 rounded-3xl p-5 flex items-center gap-5 cursor-pointer transition-colors border border-red-100"
      >
        <div className="bg-red-100 text-red-600 p-4 rounded-full shrink-0">
          <AlertCircle className="w-6 h-6" />
        </div>
        <div>
          <h3 className="font-medium text-red-900 text-lg">Voice SOS</h3>
          <p className="text-sm text-red-700/80 mt-1 leading-relaxed">
            Say <strong>"HELP"</strong> to trigger emergency protocols.
          </p>
        </div>
      </div>

      {/* Heart Rate Monitoring (PPG) */}
      <section>
        <div className="flex justify-between items-end mb-4 px-1">
          <h2 className="font-medium text-lg text-foreground/80">Heart Rate (PPG)</h2>
          <span className="text-xs text-muted-foreground">Updated 2h ago</span>
        </div>
        <div className="bg-card rounded-3xl p-6 shadow-[0_2px_20px_-10px_rgba(0,0,0,0.05)] border border-border">
          <div className="flex items-center gap-4 mb-5">
            <div className="bg-rose-50 p-3 rounded-2xl text-rose-500">
              <HeartPulse className="w-6 h-6" />
            </div>
            <div className="flex-1">
              <p className="text-sm text-muted-foreground">Last Measured</p>
              <p className="text-3xl font-semibold">74 <span className="text-base font-normal text-muted-foreground">bpm</span></p>
            </div>
          </div>
          
          <button className="w-full bg-rose-50 hover:bg-rose-100 text-rose-600 font-medium py-3.5 rounded-2xl flex items-center justify-center gap-2 transition-colors">
            <Camera className="w-5 h-5" />
            Measure via Camera Flash
          </button>
          
          <div className="w-full h-px bg-border my-5" />
          
          <p className="text-[15px] text-muted-foreground leading-relaxed">
            <span className="font-medium text-foreground">AI Note:</span> Cardiac rhythms are stable today. Vitals remain within normal limits. Remember your anticoagulants at 8:00 PM.
          </p>
        </div>
      </section>

      {/* Emergency Context */}
      <section>
        <h2 className="font-medium text-lg text-foreground/80 mb-4 px-1">Emergency Context</h2>
        <div className="space-y-3">
          <div className="bg-card rounded-2xl p-4 shadow-sm border border-border flex items-center gap-4">
            <div className="bg-blue-50 p-3 rounded-xl text-blue-600 shrink-0">
              <MapPin className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium">Nearest Hospital</p>
              <p className="text-[15px] text-muted-foreground mt-0.5">St. Jude Medical • 1.2 mi</p>
            </div>
          </div>

          <div className="bg-card rounded-2xl p-4 shadow-sm border border-border flex items-center gap-4">
            <div className="bg-emerald-50 p-3 rounded-xl text-emerald-600 shrink-0">
              <Phone className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium">Primary Contact</p>
              <p className="text-[15px] text-muted-foreground mt-0.5">Sarah (Wife) • 555-019-8472</p>
            </div>
          </div>

          <div className="bg-card rounded-2xl p-4 shadow-sm border border-border flex items-center gap-4">
            <div className="bg-gray-50 p-3 rounded-xl text-gray-500 shrink-0">
              <User className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium">Home Address</p>
              <p className="text-[15px] text-muted-foreground mt-0.5">442 Grove St, SF</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}