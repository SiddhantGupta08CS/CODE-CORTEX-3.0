import { FileText, HeartPulse, ActivitySquare, Pill, ChevronRight, FileImage } from "lucide-react";

export default function Records() {
  return (
    <div className="p-6 space-y-10">
      <header className="pt-2">
        <h1 className="text-3xl font-semibold tracking-tight mb-2">Records</h1>
        <p className="text-muted-foreground text-sm">Your medical history and scans.</p>
      </header>

      {/* Conditions */}
      <section>
        <h2 className="font-medium text-lg text-foreground/80 mb-4 px-1">Conditions</h2>
        <div className="bg-card rounded-3xl border border-border overflow-hidden shadow-[0_2px_20px_-10px_rgba(0,0,0,0.05)]">
          <div className="flex items-center justify-between p-5 border-b border-border hover:bg-muted/30 cursor-pointer transition-colors">
            <div className="flex items-center gap-4">
              <div className="bg-rose-50 text-rose-500 p-3 rounded-2xl">
                <HeartPulse className="w-6 h-6" />
              </div>
              <div>
                <p className="font-medium text-base">Atrial Fibrillation</p>
                <p className="text-sm text-muted-foreground mt-0.5">Since Oct 2021</p>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-muted-foreground/50" />
          </div>
          <div className="flex items-center justify-between p-5 hover:bg-muted/30 cursor-pointer transition-colors">
            <div className="flex items-center gap-4">
              <div className="bg-blue-50 text-blue-500 p-3 rounded-2xl">
                <ActivitySquare className="w-6 h-6" />
              </div>
              <div>
                <p className="font-medium text-base">Type 2 Diabetes</p>
                <p className="text-sm text-muted-foreground mt-0.5">Since Mar 2019</p>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-muted-foreground/50" />
          </div>
        </div>
      </section>

      {/* Heart Scans */}
      <section>
        <h2 className="font-medium text-lg text-foreground/80 mb-4 px-1">Recent Scans</h2>
        <div className="space-y-3">
          <div className="bg-card border border-border p-5 rounded-3xl shadow-sm flex items-center justify-between cursor-pointer hover:bg-muted/30 transition-colors">
            <div className="flex items-center gap-4">
              <div className="bg-indigo-50 text-indigo-500 p-3 rounded-2xl">
                <FileImage className="w-6 h-6" />
              </div>
              <div>
                <p className="font-medium text-base">ECG Report</p>
                <p className="text-sm text-muted-foreground mt-0.5">Nov 12, 2024</p>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-muted-foreground/50" />
          </div>
          
          <div className="bg-card border border-border p-5 rounded-3xl shadow-sm flex items-center justify-between cursor-pointer hover:bg-muted/30 transition-colors">
            <div className="flex items-center gap-4">
              <div className="bg-indigo-50 text-indigo-500 p-3 rounded-2xl">
                <FileImage className="w-6 h-6" />
              </div>
              <div>
                <p className="font-medium text-base">Echocardiogram</p>
                <p className="text-sm text-muted-foreground mt-0.5">Aug 05, 2024</p>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-muted-foreground/50" />
          </div>
        </div>
      </section>

      {/* Medications */}
      <section>
        <h2 className="font-medium text-lg text-foreground/80 mb-4 px-1">Medications</h2>
        <div className="bg-card border border-border rounded-3xl p-5 shadow-sm space-y-5">
          <div className="flex items-center gap-4">
            <div className="bg-emerald-50 p-3 rounded-2xl text-emerald-500">
              <Pill className="w-6 h-6" />
            </div>
            <div className="flex-1">
              <p className="font-medium text-base">Apixaban (Eliquis)</p>
              <p className="text-sm text-muted-foreground mt-0.5">5mg • Twice daily</p>
            </div>
          </div>
          <div className="w-full h-px bg-border" />
          <div className="flex items-center gap-4">
            <div className="bg-emerald-50 p-3 rounded-2xl text-emerald-500">
              <Pill className="w-6 h-6" />
            </div>
            <div className="flex-1">
              <p className="font-medium text-base">Metformin</p>
              <p className="text-sm text-muted-foreground mt-0.5">500mg • Once daily</p>
            </div>
          </div>
        </div>
      </section>

      {/* Full AI Report Link */}
      <button className="w-full bg-blue-50 hover:bg-blue-100 text-blue-600 font-medium py-4 rounded-2xl flex items-center justify-center gap-2 transition-colors mt-8">
        <FileText className="w-5 h-5" />
        Generate Full AI Report
      </button>

    </div>
  );
}