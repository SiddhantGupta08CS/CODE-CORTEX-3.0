import { Phone, MessageSquare, Calendar, MapPin, Building, Mail } from "lucide-react";

export default function Doctor() {
  return (
    <div className="p-6 space-y-8">
      <header className="pt-2">
        <h1 className="text-3xl font-semibold tracking-tight mb-2">Care Team</h1>
        <p className="text-muted-foreground text-sm">Your primary specialists.</p>
      </header>

      {/* Main Doctor Profile */}
      <div className="bg-card rounded-3xl border border-border shadow-[0_2px_20px_-10px_rgba(0,0,0,0.05)] overflow-hidden">
        
        <div className="p-8 text-center flex flex-col items-center">
          <div className="w-28 h-28 rounded-full bg-muted mb-5 overflow-hidden">
            <img 
              src="https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=200&h=200&fit=crop&auto=format" 
              alt="Dr. Sarah Jenkins"
              className="w-full h-full object-cover"
            />
          </div>
          <h2 className="text-2xl font-semibold mb-1">Dr. S. Jenkins</h2>
          <p className="text-muted-foreground text-[15px]">Cardiology Specialist</p>
        </div>
        
        {/* Quick Actions */}
        <div className="flex px-6 pb-8 gap-3">
          <button className="flex-1 bg-blue-50 hover:bg-blue-100 text-blue-600 py-3 rounded-2xl flex flex-col items-center justify-center gap-1.5 transition-colors">
            <Phone className="w-5 h-5" />
            <span className="text-sm font-medium">Call</span>
          </button>
          <button className="flex-1 bg-blue-50 hover:bg-blue-100 text-blue-600 py-3 rounded-2xl flex flex-col items-center justify-center gap-1.5 transition-colors">
            <MessageSquare className="w-5 h-5" />
            <span className="text-sm font-medium">Message</span>
          </button>
          <button className="flex-1 bg-blue-50 hover:bg-blue-100 text-blue-600 py-3 rounded-2xl flex flex-col items-center justify-center gap-1.5 transition-colors">
            <Calendar className="w-5 h-5" />
            <span className="text-sm font-medium">Book</span>
          </button>
        </div>
      </div>

      {/* Details List */}
      <div className="space-y-4 px-2">
        <h2 className="font-medium text-lg text-foreground/80 mb-2">Practice Details</h2>
        
        <div className="flex items-start gap-4">
          <div className="bg-gray-100 p-3 rounded-2xl text-gray-600 shrink-0">
            <Building className="w-5 h-5" />
          </div>
          <div className="pt-1">
            <p className="text-base font-medium">St. Jude Medical Center</p>
            <p className="text-[15px] text-muted-foreground mt-0.5">Cardiovascular Wing, Floor 4</p>
          </div>
        </div>

        <div className="flex items-start gap-4">
          <div className="bg-gray-100 p-3 rounded-2xl text-gray-600 shrink-0">
            <MapPin className="w-5 h-5" />
          </div>
          <div className="pt-1">
            <p className="text-base font-medium">1200 Health Way</p>
            <p className="text-[15px] text-muted-foreground mt-0.5">San Francisco, CA 94110</p>
          </div>
        </div>

        <div className="flex items-start gap-4">
          <div className="bg-gray-100 p-3 rounded-2xl text-gray-600 shrink-0">
            <Mail className="w-5 h-5" />
          </div>
          <div className="pt-1">
            <p className="text-base font-medium">s.jenkins@stjude-med.org</p>
            <p className="text-[15px] text-muted-foreground mt-0.5">Response time: ~4 hours</p>
          </div>
        </div>
      </div>

    </div>
  );
}